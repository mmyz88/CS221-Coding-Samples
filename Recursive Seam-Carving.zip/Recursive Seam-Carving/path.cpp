#include "path.h"
#include <queue>
#include <stack>
using namespace std;

path::path(const PNG & im, pair<int,int> s, pair<int,int> e)
   :start(s),end(e),image(im){
    BFS();
}

void path::BFS() {
	// initialize working vectors
	vector<vector<bool>> V(image.height(), vector<bool> (image.width(),false));
	vector<vector<pair<int,int>>> P(image.height(), vector<pair<int,int>> (image.width(),end));

  queue<pair<int,int>> q;
  q.push(start);
  V[start.second][start.first] = true;

  while (!q.empty()) {
    pair<int,int> curr = q.front();
    if (curr == end) break;
    q.pop();
    vector<pair<int,int>> adj = neighbors(curr);
    for (size_t i = 0; i < adj.size(); ++i) {
      if (good(V, curr, adj[i])) {
          q.push(adj[i]);
          V[adj[i].second][adj[i].first] = true;
          P[adj[i].second][adj[i].first] = curr;
        }
      }
    }

	pathPts = assemble(P,start,end);
}

PNG path::render() {
  PNG output = PNG(image);
  for (unsigned int i = 0; i<pathPts.size(); i++) {
    RGBAPixel* pixel = output.getPixel(pathPts[i].first, pathPts[i].second);
    pixel->r = 255;
    pixel->g = 0;
    pixel->b = 0;
  }

  return output;
}

vector<pair<int,int>> path::getPath() { return pathPts;}

int path::length() { return pathPts.size();}

bool path::good(vector<vector<bool>> & v, pair<int,int> curr, pair<int,int> next){

    if (curr.first  >= (int) image.width()  || curr.first  < 0 ||
        curr.second >= (int) image.height() || curr.second < 0 ||
        next.first  >= (int) image.width()  || next.first  < 0 ||
        next.second >= (int) image.height() || next.second < 0)
      return false;

    if (v[next.second][next.first] == true)
      return false;

    RGBAPixel* currPixel = image.getPixel(curr.first, curr.second);
    RGBAPixel* nextPixel = image.getPixel(next.first, next.second);
    if (!closeEnough(*currPixel, *nextPixel))
      return false;

    return true;
}

vector<pair<int,int>> path::neighbors(pair<int,int> curr) {
	vector<pair<int,int>> n;

  n.push_back(make_pair(curr.first-1, curr.second));
  n.push_back(make_pair(curr.first, curr.second+1));
  n.push_back(make_pair(curr.first+1, curr.second));
  n.push_back(make_pair(curr.first, curr.second-1));

  return n;
}

vector<pair<int,int>> path::assemble(vector<vector<pair<int,int>>> & p, pair<int,int> s, pair<int,int> e) {

  stack<pair<int,int>> S;
  vector<pair<int,int>> output;

  S.push(e);

  while (S.top() != s) {
    pair<int,int> top = S.top();
    pair<int,int> next = p[top.second][top.first];
    S.push(next);
  }

  while (!S.empty()) {
    output.push_back(S.top());
    S.pop();
  }
  //cout << output.size() << endl;
  return output;
}

bool path::closeEnough(RGBAPixel p1, RGBAPixel p2){
   int dist = (p1.r-p2.r)*(p1.r-p2.r) + (p1.g-p2.g)*(p1.g-p2.g) +
               (p1.b-p2.b)*(p1.b-p2.b);

   return (dist <= 80);
}
