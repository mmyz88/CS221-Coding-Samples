
/**
 *
 * twoDtree (pa3)
 * slight modification of a Kd tree of dimension 2.
 * twoDtree.cpp
 * This file will be used for grading.
 *
 */

#include "twoDtree.h"

/* given */
twoDtree::Node::Node(pair<int,int> ul, pair<int,int> lr, RGBAPixel a)
	: upLeft(ul),lowRight(lr),avg(a),left(NULL),right(NULL)
{
}

/* given */
twoDtree::~twoDtree(){
	clear();
}

/* given */
twoDtree::twoDtree(const twoDtree & other) {
	copy(other);
}

/* given */
twoDtree & twoDtree::operator=(const twoDtree & rhs){
	if (this != &rhs) {
		clear();
		copy(rhs);
	}
	return *this;
}

twoDtree::twoDtree(PNG & imIn) {
	pair<int,int> ul = make_pair(0, 0);
	pair<int,int> lr = make_pair(imIn.width()-1, imIn.height()-1);
	width = imIn.width();
	height = imIn.height();
	stats imStats(imIn);

	root = new Node(ul, lr, imStats.getAvg(ul, lr));

	twoDtree::partitionStruct parted = partition(imStats, ul, lr);

	root->left = buildTree(imStats, parted.upLeft1, parted.lowRight1);
	root->right = buildTree(imStats, parted.upLeft2, parted.lowRight2);


}

twoDtree::partitionStruct twoDtree::partition(stats &imStats, pair<int,int> ul, pair<int,int> lr) {
	long min = 10000000000000000;
	twoDtree::partitionStruct parted;
	pair<int,int> ul2;
	pair<int,int> lr2;
	int partWidth = lr.first - ul.first;
	int partHeight = lr.second - ul.second;

	//vertical split
	for (int x = 0; x < partWidth; x++) {
		long temp = imStats.getScore(ul, make_pair(ul.first+x, lr.second))
		 						+ imStats.getScore(make_pair(ul.first+x+1,ul.second), lr);
		if (temp < min) {
			min = temp;
			ul2 = make_pair(ul.first+x+1,ul.second);
			lr2 = make_pair(ul.first+x, lr.second);
		}
	}

	//horizontal split
	for (int y = 0; y < partHeight; y++) {
		long temp = imStats.getScore(ul, make_pair(lr.first, ul.second+y))
								+ imStats.getScore(make_pair(ul.first, ul.second+y+1), lr);
		if (temp < min) {
			min = temp;
			ul2 = make_pair(ul.first, ul.second+y+1);
			lr2 = make_pair(lr.first, ul.second+y);
		}
	}

	parted.upLeft1 = ul;
	parted.upLeft2 = ul2;
	parted.lowRight1 = lr2;
	parted.lowRight2 = lr;
	return parted;
}

twoDtree::Node * twoDtree::buildTree(stats & s, pair<int,int> ul, pair<int,int> lr) {
	if (s.rectArea(ul,lr) == 1)
		return new Node(ul, lr, s.getAvg(ul, lr));
	twoDtree::partitionStruct parted = partition(s, ul, lr);

	Node* thisNode = new Node(ul, lr, s.getAvg(ul, lr));
	thisNode->left = buildTree(s, parted.upLeft1, parted.lowRight1);
	thisNode->right = buildTree(s, parted.upLeft2, parted.lowRight2);
	return thisNode;
}

PNG twoDtree::render(){
	if (root == NULL) return PNG();
  PNG png(width, height);
	recursiveRender(png, root);
	return png;
}

void twoDtree::recursiveRender(PNG &png, Node* root){
	if (root->left != NULL) recursiveRender(png, root->left);
	if (root->right != NULL) recursiveRender(png, root->right);

	if (root->left == NULL && root->right == NULL) {
		for (int i = root->upLeft.first; i < root->lowRight.first + 1; i++) {
			for (int j = root->upLeft.second; j < root->lowRight.second + 1; j++) {
				RGBAPixel* pixel = png.getPixel(i,j);
				*pixel = RGBAPixel(root->avg);
			}
		}
	}
}

void twoDtree::prune(double pct, int tol){
	recursivePrune(pct, tol, root);
}

void twoDtree::recursivePrune(double pct, int tol, Node* root) {
	if (root == NULL) return;

	if (!isThreshold(pct, tol, root)) {
		recursivePrune(pct, tol, root->left);
		recursivePrune(pct, tol, root->right);
	}
	else {
		recursiveClear(root->left);
		recursiveClear(root->right);
	}
}

bool twoDtree::isThreshold(double pct, int tol, Node* root) {
	if (root->left == NULL && root->right == NULL) return false; //the end

	RGBAPixel avgPixel = root->avg;
	pair<int,int> pct_pair = recursiveThreshold(tol, root, avgPixel);
	if (pct_pair.first/pct_pair.second >= pct) return true;
	else return false;
}

pair<int,int> twoDtree::recursiveThreshold(int tol, Node* root, RGBAPixel &avgPixel) {
	if (root->left == NULL && root->right == NULL) {
		int diff = (root->avg.r - avgPixel.r) * (root->avg.r - avgPixel.r) +
							 (root->avg.g - avgPixel.g) * (root->avg.g - avgPixel.g) +
							 (root->avg.b - avgPixel.b) * (root->avg.b - avgPixel.b);
	  if (diff <= tol) return make_pair(1, 1);
		else return make_pair(0,1);
	}

	pair<int,int> this_pct_pair;
	if (root->left != NULL)
		this_pct_pair = recursiveThreshold(tol, root->left, avgPixel);
	if (root->right != NULL) {
		pair<int,int> next_pct_pair = recursiveThreshold(tol, root->right, avgPixel);
		this_pct_pair.first += next_pct_pair.first;
		this_pct_pair.second += next_pct_pair.second;
	}

	return this_pct_pair;
}

void twoDtree::clear() {
	recursiveClear(root);
}

void twoDtree::recursiveClear(Node* &root) {
	if (root == NULL) return;
	recursiveClear(root->left);
	recursiveClear(root->right);
	delete(root);
	root = NULL;
}

void twoDtree::copy(const twoDtree &orig){
	root = new Node (orig.root->upLeft, orig.root->lowRight, orig.root->avg);
	root->left = recursiveCopy(orig.root->left);
	root->right = recursiveCopy(orig.root->right);
	width = orig.width;
	height = orig.height;
}

twoDtree::Node* twoDtree::recursiveCopy(Node* origNode) {
	if (origNode == NULL) return NULL;
	Node* newNode = new Node (origNode->upLeft, origNode->lowRight, origNode->avg);
	newNode->left = recursiveCopy(origNode->left);
	newNode->right = recursiveCopy(origNode->right);
	return newNode;
}
