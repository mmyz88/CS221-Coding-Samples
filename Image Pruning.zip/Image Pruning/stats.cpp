
#include "cs221util/PNG.h"
#include "cs221util/RGBAPixel.h"
#include "stats.h"
#include <utility>
#include <vector>
using namespace std;
using namespace cs221util;

vector< vector< long >> sumRed;
vector< vector< long >> sumGreen;
vector< vector< long >> sumBlue;
vector< vector< long >> sumsqRed;
vector< vector< long >> sumsqGreen;
vector< vector< long >> sumsqBlue;


long stats::getSum(char channel, pair<int,int> ul, pair<int,int> lr) {
  if (channel == 'r') {
    if (ul.first == 0 && ul.second == 0)
      return sumRed[lr.first][lr.second];
    else if (ul.first == 0)
      return sumRed[lr.first][lr.second] - sumRed[lr.first][ul.second-1];
    else if (ul.second == 0)
      return sumRed[lr.first][lr.second] - sumRed[ul.first-1][lr.second];
    else
		  return sumRed[lr.first][lr.second] - sumRed[ul.first-1][lr.second]
            - sumRed[lr.first][ul.second-1] + sumRed[ul.first-1][ul.second-1];
  }
  else if (channel == 'g') {
    if (ul.first == 0 && ul.second == 0)
      return sumGreen[lr.first][lr.second];
    else if (ul.first == 0)
      return sumGreen[lr.first][lr.second] - sumGreen[lr.first][ul.second-1];
    else if (ul.second == 0)
      return sumGreen[lr.first][lr.second] - sumGreen[ul.first-1][lr.second];
    else
		  return sumGreen[lr.first][lr.second] - sumGreen[ul.first-1][lr.second]
            - sumGreen[lr.first][ul.second-1] + sumGreen[ul.first-1][ul.second-1];
  }
  else if (channel == 'b') {
    if (ul.first == 0 && ul.second == 0)
      return sumBlue[lr.first][lr.second];
    else if (ul.first == 0)
      return sumBlue[lr.first][lr.second] - sumBlue[lr.first][ul.second-1];
    else if (ul.second == 0)
      return sumBlue[lr.first][lr.second] - sumBlue[ul.first-1][lr.second];
    else
		  return sumBlue[lr.first][lr.second] - sumBlue[ul.first-1][lr.second]
            - sumBlue[lr.first][ul.second-1] + sumBlue[ul.first-1][ul.second-1];
  }
	else return 0;
}

long stats::getSumSq(char channel, pair<int,int> ul, pair<int,int> lr) {
  if (channel == 'r') {
    if (ul.first == 0 && ul.second == 0)
      return sumsqRed[lr.first][lr.second];
    else if (ul.first == 0)
      return sumsqRed[lr.first][lr.second] - sumsqRed[lr.first][ul.second-1];
    else if (ul.second == 0)
      return sumsqRed[lr.first][lr.second] - sumsqRed[ul.first-1][lr.second];
    else
      return sumsqRed[lr.first][lr.second] - sumsqRed[ul.first-1][lr.second]
            - sumsqRed[lr.first][ul.second-1] + sumsqRed[ul.first-1][ul.second-1];
  }
  else if (channel == 'g') {
    if (ul.first == 0 && ul.second == 0)
      return sumsqGreen[lr.first][lr.second];
    else if (ul.first == 0)
      return sumsqGreen[lr.first][lr.second] - sumsqGreen[lr.first][ul.second-1];
    else if (ul.second == 0)
      return sumsqGreen[lr.first][lr.second] - sumsqGreen[ul.first-1][lr.second];
    else
      return sumsqGreen[lr.first][lr.second] - sumsqGreen[ul.first-1][lr.second]
            - sumsqGreen[lr.first][ul.second-1] + sumsqGreen[ul.first-1][ul.second-1];
  }
  else if (channel == 'b') {
    if (ul.first == 0 && ul.second == 0)
      return sumsqBlue[lr.first][lr.second];
    else if (ul.first == 0)
      return sumsqBlue[lr.first][lr.second] - sumsqBlue[lr.first][ul.second-1];
    else if (ul.second == 0)
      return sumsqBlue[lr.first][lr.second] - sumsqBlue[ul.first-1][lr.second];
    else
      return sumsqBlue[lr.first][lr.second] - sumsqBlue[ul.first-1][lr.second]
            - sumsqBlue[lr.first][ul.second-1] + sumsqBlue[ul.first-1][ul.second-1];
  }
  else return 0;
}

stats::stats(PNG & im) {
	  for (unsigned int i = 0; i < im.width(); i++) {
	    long cumRed = 0,   cumsqRed = 0;
	    long cumGreen = 0, cumsqGreen = 0;
	    long cumBlue = 0,  cumsqBlue = 0;
	    vector<long> redCol,   redsqCol;
	    vector<long> greenCol, greensqCol;
	    vector<long> blueCol,  bluesqCol;
	    for (unsigned int j = 0; j < im.height(); j++) {
				RGBAPixel *pixel = im.getPixel(i,j);

	      if (i == 0) {
          cumRed     += pixel->r;
          cumGreen   += pixel->g;
          cumBlue    += pixel->b;
          cumsqRed   += pixel->r * pixel->r;
          cumsqGreen += pixel->g * pixel->g;
          cumsqBlue  += pixel->b * pixel->b;
	      }
	      else if (i > 0 && j == 0) {
          cumRed     += pixel->r + sumRed[i-1][j];
          cumGreen   += pixel->g + sumGreen[i-1][j];
          cumBlue    += pixel->b + sumBlue[i-1][j];
          cumsqRed   += pixel->r * pixel->r + sumsqRed[i-1][j];
          cumsqGreen += pixel->g * pixel->g + sumsqGreen[i-1][j];
          cumsqBlue  += pixel->b * pixel->b + sumsqBlue[i-1][j];
        }
        else {
          cumRed     += pixel->r + sumRed[i-1][j] - sumRed[i-1][j-1];
          cumGreen   += pixel->g + sumGreen[i-1][j] - sumGreen[i-1][j-1];
          cumBlue    += pixel->b + sumBlue[i-1][j] - sumBlue[i-1][j-1];
          cumsqRed   += pixel->r * pixel->r + sumsqRed[i-1][j] - sumsqRed[i-1][j-1];
          cumsqGreen += pixel->g * pixel->g + sumsqGreen[i-1][j] - sumsqGreen[i-1][j-1];
          cumsqBlue  += pixel->b * pixel->b + sumsqBlue[i-1][j] - sumsqBlue[i-1][j-1];
	      }

	      redCol.     push_back(cumRed);
	      greenCol.   push_back(cumGreen);
	      blueCol.    push_back(cumBlue);
	      redsqCol.   push_back(cumsqRed);
	      greensqCol. push_back(cumsqGreen);
	      bluesqCol.  push_back(cumsqBlue);
	    }

	    sumRed.     push_back(redCol);
	    sumGreen.   push_back(greenCol);
	    sumBlue.    push_back(blueCol);
	    sumsqRed.   push_back(redsqCol);
	    sumsqGreen. push_back(greensqCol);
	    sumsqBlue.  push_back(bluesqCol);
	  }

    width_ = im.width();
    height_ = im.height();
}

long stats::getScore(pair<int,int> ul, pair<int,int> lr) {
  long redScore   = getSumSq('r', ul, lr) - getSum('r', ul, lr) * getSum('r', ul, lr) / rectArea(ul, lr);
  long greenScore = getSumSq('g', ul, lr) - getSum('g', ul, lr) * getSum('g', ul, lr) / rectArea(ul, lr);
  long blueScore  = getSumSq('b', ul, lr) - getSum('b', ul, lr) * getSum('b', ul, lr) / rectArea(ul, lr);
  return redScore + greenScore + blueScore;
}

RGBAPixel stats::getAvg(pair<int,int> ul, pair<int,int> lr) {
  RGBAPixel pixel = RGBAPixel();
  pixel.r = getSum('r', ul, lr) / rectArea(ul, lr);
  pixel.g = getSum('g', ul, lr) / rectArea(ul, lr);
  pixel.b = getSum('b', ul, lr) / rectArea(ul, lr);
  return pixel;
}

long stats::rectArea(pair<int,int> ul, pair<int,int> lr) {
  int width  = lr.second - ul.second + 1;
  int height = lr.first - ul.first + 1;
  return width * height;
}

long stats::width() {
  return width_;
}

long stats::height() {
  return height_;
}
